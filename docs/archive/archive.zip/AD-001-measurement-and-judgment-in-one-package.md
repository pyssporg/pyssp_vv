---
id: AD-001
title: Measurement and Judgment in One Package
summary: Measurement and judgment ship in one distribution as two modules, with the import split enforced by test.
date: 2026-10-22
status: accepted
layers: [architecture, implementation]
state: 02-architecture/architecture-shape.md
artifacts:
  - src/pyssp_vv/measure
  - src/pyssp_vv/judge
  - src/pyssp_vv/policy
  - tests/test_layering.py
  - pyproject.toml
supersedes: []
superseded_by: []
related: []
---

# AD-001: Measurement and Judgment in One Package

## Context

Comparison lived in `pyssp_simulate`, beside engines and reference-CSV support.
That package exposed a `compare` CLI and `PairReport.passed()`.
Acceptance logic in a simulation substrate gave it a second reason to change.
`ComparisonWindow` and reference-CSV support had leaked in from a consumer.
Nothing outside `pyssp_simulate` imported that surface.

## Decision

One distribution, two modules: `pyssp_vv.measure` and `pyssp_vv.judge`.
`measure` holds series, alignment, metrics, normalisation, coverage, figures.
`judge` holds criterion, sufficiency, dispositions, verdicts; stdlib only, consuming a metric table.
`pyssp_simulate` may call `measure` internally; never re-export, never import `judge`.
`tests/test_layering.py` enforces the split.

## Rationale

A metric is not a verdict; measurement belongs next to the judgment that
consumes it.
Two distributions would buy independent release cadence at the cost of a
cross-package version matrix and policy types that reference each other.
The module boundary is enforced by an import test, so separation is real without
the packaging overhead.
`measure` depends on no pyssp project and can be cut out mechanically if a
non-SSP consumer appears.

## Alternatives Considered

- Standalone comparison and plotting library beside `pyssp_simulate.compare`: third implementation of the same metrics, thin moat, new release cadence.
- Comparison kept in `pyssp_simulate` with judgment on top: acceptance logic in the substrate; rejected after inspection.

## Consequences

- Positive: judgment is testable with fabricated metric tables — no simulation, no engines, no numpy.
- Positive: coverage and the gap rule are first-class.
- Negative: `pyssp_simulate` lost `compare`, its CLI subcommand, and `PairReport.passed()`; the upstream removal needs its own ADR there.
- Negative: a merge of the two modules would reintroduce the ambiguity this decision removes.

## Verification

`tests/test_layering.py` guards the split: contract layers stdlib-only, `measure`
numpy-only at module level, `judge` independent of `measure`, no pyssp project
imported.

## Review Trigger

A non-SSP consumer needs `measure` alone, or `pyssp_simulate` needs judgment.
Split or re-decide then.
